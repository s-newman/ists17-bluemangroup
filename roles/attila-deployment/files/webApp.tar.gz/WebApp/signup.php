<html>
    <head>
        <title> Election Donations </title>
	<style>
		body {font-family: Arial;}

	/* Style the tab */
	.tab {
    		/*overflow: hidden;*/
    		border: 1px solid #ccc;
    		background-color: #f1f1f1;
		align-items: center;																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												justify-content: center;
display: flex;
	}

	/* Style the buttons inside the tab */
	.tab button {
    		background-color: inherit;
    		float: left;
    		border: none;
    		outline: none;
    		cursor: pointer;
    		padding: 14px 16px;
    		transition: 0.3s;
    		font-size: 17px;
		align-items: center;
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																	justify-content: center;
display: flex;
	}

	/* Change background color of buttons on hover */
	.tab button:hover {
   		background-color: #ddd;
	}

	

	
</style>
    <head>
    <body>
	<div class="tab">
  		<input type="button" name="home" value="Home"  onclick="location.href='index.html'">
		<input type="button" name="login" value="Login"  onclick="location.href='login.php'">
		
		
	</div>
	<form action="create.php" method="post">
	Username: <input type="text" name="username"><br>
	Password: <input type="text" name="password"><br>
	<input type="submit" value="Create Account">
	</form>
<html>
